# Typora-Solarized

This Solarized theme for Typora (markdown editor) uses the same color scheme originally created by Ethan Schoonover.

**Instalation**

To install this theme, open the Preferences panel and then click on the button *Open Theme Folder*. Paste the .css files and the directory named "solarized" inside that folder. Restart typora, then select it from Theme menu.

**Mononoki**

This theme uses Mononoki, an open source monospace font for programming and code review developed for high and low resolution displays. For more details and how to download the complete files, go to the official repository:
https://github.com/madmalik/mononoki

